package com.securitysample.main;

import java.util.Arrays;

import javax.xml.bind.DatatypeConverter;

import com.securitysample.util.CipherUtil;

public class Main {

	
	public static void main(String[] args) {
		
		try {
			String message = "���ѹα� �Ϻ� �̱� ���� ĳ����";
			System.out.println("���� ���ڿ� : " + message);
			
			//Ű ����
			String base64key = CipherUtil.generateBase64Key(128);
			byte[] key = CipherUtil.generateKey(128);
			
			//Ű
			System.out.println("Base64 Key : " + base64key);
			System.out.println("Key : " + Arrays.toString(key));
			
			String base64String = CipherUtil.encryptAES128(base64key, message);
			System.out.println("EncryptAES128(base64 encode) : " + base64String);
			
			String encrypt = CipherUtil.encryptAES128(key, message);
			System.out.println("EncryptAES128 : " + encrypt);
			
		    System.out.println("DecryptAES128(base64 decode) : " + CipherUtil.decryptAES128(base64key, base64String));
		    System.out.println("DecryptAES128 : " + CipherUtil.decryptAES128(key, encrypt));
		    
		} catch (Exception e) {
			e.printStackTrace();
		}
 	}
	
}
