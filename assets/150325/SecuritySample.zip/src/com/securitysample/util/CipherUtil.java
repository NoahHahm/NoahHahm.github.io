package com.securitysample.util;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

public class CipherUtil {
	
	//keySize�� ���� AES ��ȣȭ Ű ���� (base64 ���ڵ� ó��)
	public static String generateBase64Key(int keySize) throws Exception {		
		
		KeyGenerator generator = KeyGenerator.getInstance("AES");
		generator.init(keySize);
		Key secretKey = generator.generateKey();
		
		return DatatypeConverter.printBase64Binary(secretKey.getEncoded());
	}
	
	//keySize�� ���� AES ��ȣȭ Ű ����
	public static byte[] generateKey(int keySize) throws Exception {		
		
		KeyGenerator generator = KeyGenerator.getInstance("AES");
		generator.init(keySize);
		Key secretKey = generator.generateKey();
		
		return secretKey.getEncoded();
	}
	
	//���ڿ��� key�� ���� ��ȣȭ �ϰ� base64 �� ���ڵ�
	public static String encryptAES128(byte[] key, String message) throws Exception {
		
		SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
		Cipher cipher = Cipher.getInstance("AES");
	    cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
	    byte[] encrypted = cipher.doFinal(message.getBytes()); //encrypt
	    
	    String encodeString = DatatypeConverter.printBase64Binary(encrypted); //Converts an array of bytes into a string.

		return encodeString;
	}
	
	//base64�� ���ڵ��� key �� ���� ���ڿ� base64 ���ڵ� 
	public static String encryptAES128(String base64Key, String message) throws Exception {
		return encryptAES128(base64DecodeKey(base64Key), message);
	}

	//key �� ���� ���ڿ� base64 ���ڵ�
	public static String decryptAES128(byte[] keys, String encrypted)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			IllegalBlockSizeException, BadPaddingException, InvalidKeyException {
		
		SecretKeySpec keySpec = new SecretKeySpec(keys, "AES");

		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, keySpec);

		byte[] decodeBytes = DatatypeConverter.parseBase64Binary(encrypted); //Converts the string argument into an array of bytes.
		byte[] decryptBytes = cipher.doFinal(decodeBytes); //decrypt
		
		return new String(decryptBytes);	
	}

	//base64�� ���ڵ��� key �� ���� ���ڿ� base64 ���ڵ�
	public static String decryptAES128(String base64Key, String encrypted)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			IllegalBlockSizeException, BadPaddingException, InvalidKeyException {
				
		return decryptAES128(base64DecodeKey(base64Key), encrypted);	
	}
	
	//base64�� ���ڵ��� key�� byte �迭�� ���ڵ�
	public static byte[] base64DecodeKey(String base64Key) {
		return DatatypeConverter.parseBase64Binary(base64Key);		
	}
	
	//byte�迭�� Ű�� base64�� ���ڵ�
	public static String base64EncodeKey(byte[] key) {
		return DatatypeConverter.printBase64Binary(key);
	}
	
}
