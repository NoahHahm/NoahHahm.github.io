class HomeController {
    
    constructor() {

    }

    static Home(req, res) {
        res.status(200).end('Home!');
    }

    static HomeTest(req, res) {
        res.status(200).end('Home Test!');
    }
}


module.exports = HomeController;