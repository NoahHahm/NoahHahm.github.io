const express = require('express');
const route = express.Router();
const handleAttach = require('./handleAttach');

route.get('/home', handleAttach('HomeController', 'Home'));
route.get('/home/test', handleAttach('HomeController', 'HomeTest'));


module.exports = route;