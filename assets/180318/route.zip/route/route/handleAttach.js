module.exports = (controllerName, funcName) => {

    if (!controllerName || !funcName) {
        throw "controller and method error."
    }

    const controller = require(`../controllers/${controllerName}`);
    if (!controller) {
        throw "controller require error."
    }

    const method = controller[funcName];
    if (!method) {
        throw "method not found error.";
    }

    return method;
}